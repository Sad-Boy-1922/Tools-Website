# wpbruteforce
Wordpress Brute Force Bia WebBased

Download zip on this repository

Upload to your hosting 

run , and enjoy it :)
